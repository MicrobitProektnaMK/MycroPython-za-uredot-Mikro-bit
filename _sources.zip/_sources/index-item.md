---
title: Projektna nastava za sedmi i osmi razred
author: Svetlana Radlovački i Milan Vugdelija
thumb: media/microbit.png
---

Ovaj priručnik namenjen je učenicima sedmog razreda osnovne škole i zamišljen je kao pomoć u realizaciji časova na kojima je planirana izrada projekata sa primenom MikroPajtona za upravljanje mikrobit uređajem.